export const spotlightsaga = {
    skills: [
    { key: "arcana",     label: "Arcana", icon: "hat-witch"},
    { key: "athletics",  label: "Athletics", icon: "hand-fist" },
    { key: "melee",      label: "Melee", icon: "swords" },
    { key: "presence",   label: "Presence", icon: "person-rays" },
    { key: "ranged",     label: "Ranged", icon: "bow-arrow" },
    { key: "reflex",     label: "Reflex", icon: "person-running" },
    { key: "finesse",    label: "Finesse", icon: "user-ninja" },
    { key: "influence",  label: "Influence", icon: "comment" },
    { key: "medicine",   label: "Medicine", icon: "prescription-bottle-medical" },
    { key: "naturecraft",label: "Naturecraft", icon: "leaf" },
    { key: "perception", label: "Perception", icon: "eye" },
    { key: "wisdom",     label: "Wisdom", icon: "head-side-brain" }
  ]
};
