export default class ssActor extends Actor {
    
}